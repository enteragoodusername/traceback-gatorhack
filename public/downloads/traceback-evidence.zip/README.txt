TRACEBACK EVIDENCE PACKET

Measured report and inspected frames. Verify with scripts/verify_packet.py.

Checksums establish file integrity, not authorship, ownership, infringement, or first publication. They are not digital signatures. The original videos are identified by hash and are not included.

Tears of Steel — (CC) Blender Foundation | mango.blender.org. CC BY 3.0. Excerpts trimmed, resized, muted and transformed.

Search is limited to the indexed source library.
A visual match is evidence of shared imagery, not proof of ownership, infringement, or first publication.
Source frames are sampled at 1 fps, then verified candidates are refined at 4 fps. Per-alignment tolerances are not guaranteed error bounds or statistical confidence intervals.
Semantic similarities are uncalibrated retrieval scores, not probabilities.
The playback speed range is a deterministic consistency interval under the timestamp tolerance, not a calibrated confidence interval.